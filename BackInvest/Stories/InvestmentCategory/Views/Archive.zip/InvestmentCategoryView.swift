//
//  InvestmentCategoryView.swift
//  BackInvest
//
//  Created by Timofey on 9/17/17.
//  Copyright © 2017 Jufy. All rights reserved.
//

import Foundation
import UIKit

class InvestmentCategoryView: UIView {
    
    
    
}
